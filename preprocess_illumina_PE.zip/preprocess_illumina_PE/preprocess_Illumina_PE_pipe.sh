#!/bin/bash
#SBATCH --job-name preprocess_Illumina_PE
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=1gb
#SBATCH --time=0:10:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

NAME=$1           # Name of current sample (Part of raw fastq filenames identifying the current sample to be processed)
SETTINGS_PATH=$2  # path to settings file

# Exit with error if NAME argument empty
if [ ! ${NAME} ];then
  echo "NAME argument empty"
  exit 1
fi

# Load settings
source "$SETTINGS_PATH" "$NAME"

# Load namespace
source "$PROGDIR/bin/namespace.sh" $NAME $SETTINGS_PATH

# Create output directories
mkdir -p "$LOGDIR"
mkdir -p "$DIR_TRIM_OUT"
mkdir -p "$DIR_SPLIT_OUT"

# # Print sample and settings info
# echo "current sample name: $NAME"
# echo "settings loaded from: $SETTINGS_PATH"
# echo $LOGOFLOGS

# Initiate log file
echo "current sample name: $NAME" > ${LOGOFLOGS}
echo "settings loaded from: $SETTINGS_PATH" > ${LOGOFLOGS}
echo "preprocess_Illumina_PE "${SLURM_JOB_ID} >> ${LOGOFLOGS}

# Confirm that raw data files exist
if [ ! "$RAW1FQGZ" -eq 1 ] ; then
  echo "$RAW1FQGZ does not exist"
  exit 1
fi

if [ ! "$RAW2FQGZ" -eq 1 ] ; then
  echo "$RAW2FQGZ does not exist"
  exit 1
fi

# #### JID1A
# # Decompress input R1 reads file from 'spring' to 'fastq.gz' unless already do
# JID1A=$(sbatch --job-name=preproc_1A --nodes=1 --tasks-per-node=1 --mem=5gb --time=2:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step1A.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
# echo "preproc_1A "${JID1A} >> ${LOGOFLOGS}
# 
# #### JID1B
# # Decompress input R2 reads file from 'spring' to 'fastq.gz' unless already done
# JID1B=$(sbatch --job-name preproc_1B --nodes=1 --tasks-per-node=1 --mem=5gb --time=2:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step1B.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
# echo "preproc_1B "${JID1B} >> ${LOGOFLOGS}

#### JID2
# Run trimmomatic for adapter and quality trimming
#JID2=$(sbatch --tasks-per-node=20 --time=24:00:00 --mem=50gb --dependency=afterok:${JID1A}:${JID1B} ${PROGDIR}"/preprocess_Illumina_PE_step2.sh" ${NAME} ${LOGOFLOGS} | awk '{print $4}')
JID2=$(sbatch --job-name=preproc_2 --nodes=1 --tasks-per-node=20 --mem=50gb --time=24:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step2.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
echo "preproc_2 "${JID2} >> ${LOGOFLOGS}

#### JID3
# Append files with unpaired trimmed reads
JID3=$(sbatch --job-name=preproc_3 --dependency=afterok:${JID2} --nodes=1 --tasks-per-node=1 --mem=1gb --time=1:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step3.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
echo "preproc_3 "${JID3} >> ${LOGOFLOGS}

#### JID4A
# Filter paired-end reads matching common sources of contamination
JID4A=$(sbatch --job-name=preproc_4A --dependency=afterok:${JID3} --nodes=1 --tasks-per-node=20 --mem=150gb --time=24:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step4A.sh" ${NAME} "$SETTINGS_PATH" | awk '{print $4}')
echo "preproc_4A "${JID4A} >> ${LOGOFLOGS}

#### JID4B
# Filter unpaired reads matching common sources of contamination
JID4B=$(sbatch --job-name=preproc_4B --dependency=afterok:${JID3} --nodes=1 --tasks-per-node=20 --mem=150gb --time=24:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step4B.sh" ${NAME} "$SETTINGS_PATH" | awk '{print $4}')
echo "preproc_4B "${JID4B} >> ${LOGOFLOGS}

####  JID5A and JID5B
JID5A=$(sbatch --job-name=preproc_5A --dependency=afterok:${JID4A} --nodes=1 --tasks-per-node=10 --mem=50gb --time=4:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step5A.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
JID5B=$(sbatch --job-name=preproc_5B --dependency=afterok:${JID4A} --nodes=1 --tasks-per-node=10 --mem=50gb --time=4:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step5B.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
####  JID5C
JID5C=$(sbatch --job-name=preproc_5C --dependency=afterok:${JID4B} --nodes=1 --tasks-per-node=10 --mem=25gb --time=4:00:00 --mail-type=NONE --chdir="$LOGDIR" -o=slurm-%j-%x.out -e=slurm-%j-%x.out ${BINDIR}"/preprocess_Illumina_PE_step5C.sh" ${NAME} ${SETTINGS_PATH} | awk '{print $4}')

# Record job ids in log file
echo "preproc_5A "${JID5A} >> ${LOGOFLOGS}
echo "preproc_5B "${JID5B} >> ${LOGOFLOGS}
echo "preproc_5C "${JID5C} >> ${LOGOFLOGS}

#### JID6 (SKIPPED FOR NOW)
# Remove (1) directory with trimmed (unclean) reads and (2) folder containing the bbsplit contaminant reference mapping files
# JID6=$(sbatch --dependency=afterok:${JID5A}:${JID5B}:${JID5C} ${BINDIR}"/preprocess_Illumina_PE_step6.sh" ${NAME} ${DIR_TRIM_OUT} ${DIR_SPLIT_OUT} | awk '{print $4}')
# echo "step6 "${JID6} >> ${LOGOFLOGS}
# exit 0


