#!/bin/bash

NAME=$1

PROGDIR="/home/jweinell/mendel-nas1/prog/pseudoit_unwrapped/"

# Cleaned forward reads that have cognate reverse read in $READS_PE2
READS_PE1="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_R1.fastq.gz"

# Cleaned reverse reads that have cognate forward read in $READS_PE1
READS_PE2="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_R2.fastq.gz"

# Cleaned unpaired reads (forward or reverse read with cognate read filtered during preprocessing of paired-end reads).
READS_SE="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_unpaired.fastq.gz"

# Reference genome fasta file (for gymnos and Phyllopezus)
SPECIES=$(echo $NAME | awk '{gsub("-"," ")}1' | awk '{print $2}')
[ "$SPECIES" == "amarali" ] ||  [ "$SPECIES" == "geckoides" ] ||  [ "$SPECIES" == "guttulatus" ] ||  [ "$SPECIES" == "vanzolini" ] && REFPATH_OG="/home/jweinell/mendel-nas1/AMNH_pacbio/hifiasm_assemblies/Gymnodactylus-amarali-CHUNB82010/Gymnodactylus-amarali-CHUNB82010_hifi.asm.bp.p_ctg.fa"
[ "$SPECIES" == "darwinii" ] && REFPATH_OG="/home/jweinell/mendel-nas1/AMNH_pacbio/hifiasm_assemblies/Gymnodactylus-darwinii-CHUNB82011/Gymnodactylus-darwinii-CHUNB82011_hifi_cells3and4.asm.bp.p_ctg.fa"
[ "$SPECIES" == "pollicaris" ] && REFPATH_OG="/home/jweinell/mendel-nas1/reference_genomes/Phyllodactylus-wirshingi/ncbi_db_noW/Phyllodactylus-wirshingi-NoW_reference-genome.fa"

# Main output directory
OUTDIR="/home/jweinell/mendel-nas1/pseudoit_output/"${NAME}

######### Assembly variables

# max number of processors to use (=number of processors to use for gatk haplotyping large scaffolds > 100 megabases)
MAXPROCS=20
# number of processors for gatk haplotyping mid-sized scaffolds (10–100 megabases)
MIDPROCS=8
# number of processors for gatk haplotyping small scaffolds (<10 megabases)
MINPROCS=1
# Number of threads for bwa mapping reads to ref genome
BWA_THREADS=10
# The minimum phred-scaled confidence threshold at which variants should be called (gatk default = 30)
STAND_CALL_CONF=30
# 
INDELGAP=5


#### not yet implemented

# Minimum site coverage required by $BCFTOOLSFILTER_SHPATH and $BCFTOOLSFILTER_02_SHPATH
MINSITECOV=5   
# Maximum site coverage required by $BCFTOOLSFILTER_SHPATH and $BCFTOOLSFILTER_02_SHPATH
MAXSITECOV=60  # not yet implemented
# Number of processors to use for bcftools filter (can be low because not rate-limiting)
FILTER_PROCS=1
# Whether or not to keep all intermediate files at the end of an iteration (1=TRUE;0=FALSE) # better to keep all
KEEPALL=1

