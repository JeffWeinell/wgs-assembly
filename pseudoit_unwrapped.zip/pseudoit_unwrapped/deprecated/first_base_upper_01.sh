#!/bin/bash
#SBATCH --job-name base1_upper
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=150gb
#SBATCH --time=15:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

# Load submission variables
NAME=$1
SETTINGS_PATH=$2
TABIX_SNPS_01_ID=$3

# Load environment and assembly settings
source ${SETTINGS_PATH} ${NAME}

# Load namespace
source "$PROGDIR/bin/namespace_permanent.sh" ${NAME} ${SETTINGS_PATH}

### Record that tabix for snps vcf completed successfully
echo -e ${TABIX_SNPS_01_ID}"\ttabix_snps_01\tSUCCESS\t-----" >> ${LOGOFLOGS}
### Indicate that the current job is running
echo -e ${SLURM_JOB_ID}"\tfirst_base_upper_01\tEXECUTING\t-----" >> ${LOGOFLOGS}

## # checking/making first base of each reference scaffold upper case
SEQPATH=$REFPATH_IN
SEQPATH_NEW=$SEQPATH".edit.fa"

# first base of first sequence
FIRSTBASE=$(seqkit subseq -r 1:1 $SEQPATH | seqkit range -r 1:1 | seqkit seq -s)
FIRSTBASE_NEW=$(echo "$FIRSTBASE" | tr '[:lower:]' '[:upper:]')
[ "$FIRSTBASE" = "$FIRSTBASE_NEW" ]  && exit 0
# write new first seq with first base changed to upper case to $SEQPATH_NEW
seqkit range -r 1:1 $SEQPATH | seqkit mutate -p 1:$FIRSTBASE_NEW > $SEQPATH_NEW
# append unedited other seqs (all but first seq) to $SEQPATH_NEW
seqkit range -r 2:-1 $SEQPATH >> $SEQPATH_NEW
rm $SEQPATH
mv $SEQPATH_NEW $SEQPATH

