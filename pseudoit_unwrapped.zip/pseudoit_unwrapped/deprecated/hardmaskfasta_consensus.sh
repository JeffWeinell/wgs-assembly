#!/bin/bash
#SBATCH --job-name hardmaskfasta_consensus
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=3:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

# Create a bedfile with sites where FILTER!=PASS or where sample genotype is missing (GT=./.)

NAME=$1
SETTINGS_PATH=$2
echo $NAME

# Load environment and assembly settings
source ${SETTINGS_PATH} ${NAME}

# Load namespace
source "$PROGDIR/bin/namespace_permanent.sh" ${NAME} ${SETTINGS_PATH}

# TABIX_02_ID=${2:-$(cat $LOGOFLOGS  | grep "tabix_02" | tail -n 1 | awk '{print $1}')}

# echo -e ${TABIX_02_ID}"\ttabix_02\tCOMPLETE\t-----" >> ${LOGOFLOGS}

# FILTER_VCF_02="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/vcf/iter-02-filter.vcf.gz"
# REFPATH_02="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-01/fa/iter-01-snps-intermediate.fa"
# MASKSITES_02_BED="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-masksites_v2.bed"
# REF_02_SOFTMASKED="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-01-masked_v2.fa"
# SOFTMASKED_02_FINAL_FASTA="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-softmask-final_v2.fa"
# SOFTMASKED_02_FINAL_FASTA_CHAIN="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-softmask-final_v2.chain"


# HARDMASKSITES_02_BED="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-hardmasksites_v3.bed"
# REF_02_HARDMASKED="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-01-hardmasked_v2.fa"
# HARDMASKED_02_FINAL_FASTA="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-hardmask-final_v2.fa"
# HARDMASKED_02_FINAL_FASTA_CHAIN="/home/jweinell/mendel-nas1/pseudoit_output/"$NAME"/iter-02/fa/iter-02-hardmask-final_v2.chain"

# [ ! -f "$FILTER_VCF_02" ] && exit 1
[ ! -f "$REFPATH_02" ] && exit 1

# hardmask the reference genome (uses same bedfile that was previously used for softmasking)
bedtools maskfasta -fi ${REFPATH_02} -bed ${MASKSITES_02_BED} -fo ${REF_02_HARDMASKED}

# make consensus fasta (pseudogenome)
bcftools consensus -f ${REF_02_HARDMASKED} -o ${HARDMASKED_02_FINAL_FASTA} -c ${HARDMASKED_02_FINAL_FASTA_CHAIN} -e "FILTER~'pseudoit' || FILTER~'IndelGap'" ${FILTER_VCF_02}





