#!/bin/bash
#SBATCH --job-name preproc_6
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=10mb
#SBATCH --time=0:1:00
#SBATCH --mail-type=NONE
#SBATCH --mail-user=jweine2@gmail.com
#SBATCH --chdir=/home/jweinell/mendel-nas1/logs/
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

NAME=$1           # Name of current sample (Part of raw fastq filenames identifying the current sample to be processed)
SETTINGS_FILE=$2  # path to settings file

# Load settings
source "$SETTINGS_FILE" "$NAME"





NAME=$1
DIR_TRIM_OUT=$2
DIR_SPLIT_OUT=$3


## clean up workspace
# remove input directory with trimmed pre-cleaned reads of sample 
rm -R ${DIR_TRIM_OUT}
# remove the folder containing the bbsplit contaminant reference mapping files
rm -R ${DIR_SPLIT_OUT}"/ref"
exit 0

