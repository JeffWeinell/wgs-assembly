#!/bin/bash
#SBATCH --job-name spring_decompress
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=200gb
#SBATCH --time=05:00:00
#SBATCH --mail-type=NONE
#SBATCH --mail-user=jweine2@gmail.com
#SBATCH --output=slurm-%j-%x.out

# path to input (spring) and output (fastq.gz) files
INFILE=${1}
OUTFILE=$(echo ${INFILE} | awk 'gsub("spring$","fastq.gz")')

# path to spring executable
SPRING="/home/jweinell/mendel-nas1/prog/SPRING/build/spring"

# directory where temporary files should be saved
TMP="/home/jweinell/mendel-nas1/prog/tmp"

# spring command
${SPRING} -d -i ${INFILE} -o ${OUTFILE} -w ${TMP} -g --gzip-level 9

exit 0

if [ -f "$OUTFILE" ]; then
  rm ${INFILE}
fi
