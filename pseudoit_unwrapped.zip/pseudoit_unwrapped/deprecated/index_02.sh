#!/bin/bash
#SBATCH --job-name CreateSeqDict_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=100gb
#SBATCH --time=5:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

NAME=$1
SETTINGS_PATH=$2

source $SETTINGS_PATH $NAME

# Load namespace
source "$PROGDIR/bin/namespace_permanent.sh" ${NAME} ${SETTINGS_PATH}

CLEANUP_01_ID=$(cat $LOGOFLOGS  | grep "cleanup_01" | tail -n 1 | awk '{print $1}')
echo -e ${CLEANUP_01_ID}"\tcleanup_01\tSUCCESS" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tindex_02\tEXECUTING" >> ${LOGOFLOGS}

# picard dictionary files
picard -Xmx70g CreateSequenceDictionary R=${REFPATH_02} O=${REFPATH_02_DICT}

# create samtools index files
samtools faidx ${REFPATH_02}

# create bwa index files
bwa index ${REFPATH_02}




