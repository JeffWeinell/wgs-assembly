#!/bin/bash
#SBATCH --job-name maponly
#SBATCH --nodes=1
#SBATCH --tasks-per-node=4
#SBATCH --mem=50gb
#SBATCH --time=24:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

# pseudo-it reference mapping to estimate depth of coverage
# usage: qsub ./pseudoit_maponly.sh <SampleName>
# example: qsub ./pseudoit_maponly.sh Zamenis-longissimus-CAS173169

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

REFPATH_IN=$1
READS_PE1=$2
READS_PE2=$3
READS_SE=$4
OUTDIR=$5
MAXPROCS=$6

# If no directory exists with the sample name: start pseudoit mapping
# If directory exists but doesnt contain a bam.gz file, resume pseudoit mapping
if [ ! -d "$OUTDIR" ]; then
  pseudo_it.py -ref ${REFPATH_IN} -pe1 ${READS_PE1} -pe2 ${READS_PE2} -se ${READS_SE} --maponly -p ${MAXPROCS} -o ${OUTDIR} -picard 'picard -Xmx40g' --nomkdups --keepall -tmp tmp-pi-out
elif [ ! -f "${OUTDIR}/iter-01/bam/merged-iter-01.bam.gz" ]; then
  pseudo_it.py -ref ${REFPATH_IN} -pe1 ${READS_PE1} -pe2 ${READS_PE2} -se ${READS_SE} --maponly -p ${MAXPROCS} -resume ${OUTDIR} -picard 'picard -Xmx40g' --nomkdups --keepall -tmp tmp-pi-out
fi



