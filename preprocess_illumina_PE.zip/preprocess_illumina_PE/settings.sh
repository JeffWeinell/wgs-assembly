#!/bin/bash
NAME=$1

####### path settings

# Program directory where preprocess_Illumina_PE.sh and this settings file are located
PROGDIR="$HOME/mendel-nas1/prog/preprocess_Illumina_PE/"

# # Directory containing raw reads files (fastq.gz)
# RAWREADS_DIR="$HOME/mendel-nas1/raw_illumina_DNA_reads/"
# 
# # Paths to forward and reverse raw reads files
# RAW1FQGZ=$(find $RAWREADS_DIR"/"$NAME*R1*.fastq.gz)
# RAW2FQGZ=$(find $RAWREADS_DIR"/"$NAME*R2*.fastq.gz)

RAW1FQGZ="$HOME/mendel-nas1/raw_illumina_DNA_reads/"${NAME}"_raw-DNA-reads_illumina-PE150_R1.fastq.gz"
RAW2FQGZ="$HOME/mendel-nas1/raw_illumina_DNA_reads/"${NAME}"_raw-DNA-reads_illumina-PE150_R2.fastq.gz"

# Directory where run results should be saved for current sample
OUTDIR="$HOME/mendel-nas1/preprocess_Illumina_PE_results/$NAME"

# Path to fasta containing genomes of common contaminant species (e.g., Drosophila, C. elegans)
CREF="$HOME/mendel-nas1/prog/bbmap/resources/merged_ref_3032904399224293960.fa.gz"


####### trimmomatic settings

# Number of threads allocated to trimmomatic
THREADS_TRIMMOMATIC=10

# Path to adapter sequences fasta
ADAPTERS="$PROGDIR/resources/adapters/TruSeq3-PE-2.fa"


####### bbsplit settings

# minimum identity to known contaminant for read to be filtered
MIN_ID=0.95


# ####### Future trimmomatic settings (for line in preprocess_Illumina_PE_step2.sh):
# # ILLUMINACLIP:${ADAPTERS}:2:30:10:2:keepBothReads LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36
# 
# # Number of leading bases to trim
# NTRIM_LEADING=3
# 
# # Number of trailing bases to trim
# NTRIM_TRAILING=3
# 
# # 
# SLIDINGWINDOW_MIN=4
# 
# # 
# SLIDINGWINDOW_MAX=15
# 
# # Minimum read length after trimming
# MINLEN_KEEP=36

