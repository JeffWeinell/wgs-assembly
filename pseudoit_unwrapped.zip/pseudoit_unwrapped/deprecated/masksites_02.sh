#!/bin/bash
#SBATCH --job-name masksites_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=10:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

FILTER_VCF_02=$1
MASKSITES_02_BED=$2
TABIX_02_ID=$3
LOGOFLOGS=$4

[ ! -f "$FILTER_VCF_02" ] && echo $FILTER_VCF_02" not found" && exit 1
[ ! -f "$LOGOFLOGS" ] && echo $LOGOFLOGS" not found" && exit 1

echo -e ${TABIX_02_ID}"\ttabix_02\tSUCCESS\t-----" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tmasksites_bed_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

zgrep "\./\." ${FILTER_VCF_02} | awk '{{OFS="	"; if ($0 !~ /\#/); print $1, $2-1, $2}}' | bedtools merge -i - > ${MASKSITES_02_BED}
# zgrep "\./\." ${FILTER_VCF_02} | awk '{{OFS="	"; if ($0 !~ /\#/); print $1, $2-1, $2}}' > ${FILTER_VCF_02}".temp.bed"
# bedtools merge -i ${FILTER_VCF_02}".temp.bed" > ${MASKSITES_02_BED}
