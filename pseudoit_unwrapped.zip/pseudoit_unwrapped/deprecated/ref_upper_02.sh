#!/bin/bash
#SBATCH --job-name ref_upper_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=150gb
#SBATCH --time=15:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

#REFPATH_02=$1
#MASKFASTA_02_ID=$2
#LOGOFLOGS=$3

NAME=$1
SETTINGS_PATH=$2
source ${SETTINGS_PATH} ${NAME}

[ ! -f "$REFPATH_02" ] && echo $REFPATH_02" not found" && exit 1
[ ! -f "$LOGOFLOGS" ] && echo $LOGOFLOGS" not found" && exit 1

### Record that tabix for snps vcf completed successfully
# echo -e ${MASKFASTA_02_ID}"\tbedtools_maskfasta_02\tSUCCESS\t-----" >> ${LOGOFLOGS}
### Record that the current job is running
echo -e ${SLURM_JOB_ID}"\tref_upper_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

# Make reference sequence for iteration 2 all upper case
seqkit seq -u $REFPATH_02 > $REFPATH_02".edit.fa"
# move $SEQPATH_NEW to $SEQPATH
rm $REFPATH_02
mv $REFPATH_02".edit.fa" $REFPATH_02
