#!/bin/bash
#SBATCH --job-name pseudoit_unwrapped
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=100mb
#SBATCH --time=01:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

NAME=$1
SETTINGS_PATH=$2

# Exit with error if NAME argument empty
[ ! ${NAME} ] && echo "NAME argument empty" && exit 1

# Load environment and assembly settings
source ${SETTINGS_PATH} ${NAME}

# Load namespace
source "$PROGDIR/bin/namespace_permanent.sh" ${NAME} ${SETTINGS_PATH}

### Create main output directory and temporary directory for assembly $NAME
mkdir -p "$OUTDIR"
mkdir -p "$TMPDIR"

### Save a copy of current run settings in $OUTDIR
cp "$SETTINGS_PATH" "$OUTDIR"

### Start logging
[ ! -f "$LOGOFLOGS" ] && echo -e "Job ID\tCurrent step\tStatus\tCommand" > $LOGOFLOGS

# create other directories if they dont already exist
mkdir -p "$OUTDIR/iter-01/bam"
mkdir -p "$OUTDIR/iter-01/fa"
mkdir -p "$OUTDIR/iter-01/logs"
mkdir -p "$OUTDIR/iter-01/vcf/vcf-logs"
mkdir -p "$OUTDIR/iter-01/vcf/vcf-scaff"
mkdir -p "$OUTDIR/iter-02/bam"
mkdir -p "$OUTDIR/iter-02/fa"
mkdir -p "$OUTDIR/iter-02/logs"
mkdir -p "$OUTDIR/iter-02/vcf/gvcf-logs"
mkdir -p "$OUTDIR/iter-02/vcf/gvcf-scaff"

######################################
# sbatch ------> iteration 1 mapping #
######################################

PU1A_ID=$(sbatch --job-name=pu1a --mail-type=NONE --nodes=1 --tasks-per-node=1 --mem=100mb --time=24:00:00 --chdir=$OUTDIR"/iter-01/logs/"  -o "PU1A.log"  -e "PU1A.log" $PU1A_SHPATH ${NAME} ${SETTINGS_PATH} | awk '{print $4}')
echo -e ${PU1A_ID}"\tpu1a\tSUBMITTED\t---" >> $LOGOFLOGS

exit 0
