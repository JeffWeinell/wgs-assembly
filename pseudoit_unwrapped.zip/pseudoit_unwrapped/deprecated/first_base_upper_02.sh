#!/bin/bash
#SBATCH --job-name base1_upper_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=1
#SBATCH --mem=150gb
#SBATCH --time=15:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

REFPATH_02=$1
MASKFASTA_02_ID=$2
LOGOFLOGS=$3

[ ! -f "$REFPATH_02" ] && echo $REFPATH_02" not found" && exit 1
[ ! -f "$LOGOFLOGS" ] && echo $LOGOFLOGS" not found" && exit 1

### Record that tabix for snps vcf completed successfully
echo -e ${MASKFASTA_02_ID}"\tbedtools_maskfasta_02\tSUCCESS\t-----" >> ${LOGOFLOGS}

### Record that the current job is running
echo -e ${SLURM_JOB_ID}"\tfirst_base_upper_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

## # checking/making first base of each reference scaffold upper case
SEQPATH=$REFPATH_IN
SEQPATH_NEW=$SEQPATH".edit.fa"
# get first base of first sequence
FIRSTBASE=$(seqkit subseq -r 1:1 $SEQPATH | seqkit range -r 1:1 | seqkit seq -s)
# same first base but uppercase
FIRSTBASE_NEW=$(echo "$FIRSTBASE" | tr '[:lower:]' '[:upper:]')
# if $FIRSTBASE is already uppercase, then exit because nothing to do
[ "$FIRSTBASE" = "$FIRSTBASE_NEW" ]  && exit 0
# else, write first sequence with first base changed to upper case to $SEQPATH_NEW
seqkit range -r 1:1 $SEQPATH | seqkit mutate -p 1:$FIRSTBASE_NEW > $SEQPATH_NEW
# append other ref seqs (unedited) to $SEQPATH_NEW
seqkit range -r 2:-1 $SEQPATH >> $SEQPATH_NEW
# move $SEQPATH_NEW to $SEQPATH
rm $SEQPATH
mv $SEQPATH_NEW $SEQPATH



