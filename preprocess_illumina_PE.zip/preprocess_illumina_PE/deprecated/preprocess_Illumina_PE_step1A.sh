#!/bin/bash

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it

NAME=$1
SETTINGS_FILE=$2

source "$SETTINGS_FILE" "$NAME"

# If R1 .fastq.gz already exists, end step1A
if [ $(ls $DIR_TRIM_IN | grep $NAME.*R1.*\\.fastq.gz | wc -l ) -eq 1 ]; then
  exit 0
# elseif R1 .spring exists, decompress to fastq.gz
elif [ $(ls $DIR_TRIM_IN | grep $NAME.*R1.*\\.spring | wc -l ) -eq 1 ]; then
  # path for spring-compressed raw forward reads file
  RAW1SPRING=$(find $DIR_TRIM_IN"/"$NAME*R1*.spring)
  # decompress from spring to fastq.gz
  bash ${PROGDIR}"/spring_decompress.sh" ${RAW1SPRING}

# else exit with error (if no R1 .spring or .fastq.gz)
else
  exit 1
fi


