#!/bin/bash
#SBATCH --job-name bwa_index_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=100gb
#SBATCH --time=5:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

##### make a file $BWAINDEX_02_SHPATH with these lines:
REFPATH_02=$1
LOGOFLOGS=$2

echo -e ${SLURM_JOB_ID}"\tbwa_index_02\tEXECUTING" >> ${LOGOFLOGS}

bwa index ${REFPATH_02}

