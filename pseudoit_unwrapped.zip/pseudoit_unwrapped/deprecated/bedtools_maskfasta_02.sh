#!/bin/bash
#SBATCH --job-name bedtools_makefasta_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=10:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

REFPATH_02=$1
MASKSITES_02_BED=$2
REF_02_SOFTMASKED=$3
MASKSITES_02_ID=$4
LOGOFLOGS=$5

[ ! -f "$REFPATH_02" ] && echo $REFPATH_02" not found" && exit 1
[ ! -f "$MASKSITES_02_BED" ] && echo $MASKSITES_02_BED" not found" && exit 1
[ ! -f "$LOGOFLOGS" ] && echo $LOGOFLOGS" not found" && exit 1

echo -e ${MASKSITES_02_ID}"\tmasksites_bed_02\tSUCCESS\t-----" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tbedtools_maskfasta_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

bedtools maskfasta -fi ${REFPATH_02} -bed ${MASKSITES_02_BED} -soft -fo ${REF_02_SOFTMASKED}
