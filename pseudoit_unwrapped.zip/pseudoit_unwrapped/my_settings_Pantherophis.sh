#!/bin/bash

NAME=$1

PROGDIR="$HOME/mendel-nas1/prog/pseudoit_unwrapped/"

# Cleaned forward reads that have cognate reverse read in $READS_PE2
READS_PE1="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_R1.fastq.gz"
# Cleaned reverse reads that have cognate forward read in $READS_PE1
READS_PE2="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_R2.fastq.gz"
# Cleaned unpaired reads (forward or reverse read with cognate read filtered during preprocessing of paired-end reads).
READS_SE="/shared_data/osn/herp-refdata/clean_illumina_DNA_reads/"${NAME}"/"${NAME}"_cleaned-DNA-reads_illumina-PE150_unpaired.fastq.gz"

# Reference genome fasta file
REFPATH_OG="$HOME/mendel-nas1/reference_genomes/Pantherophis-alleghaniensis_PanAll1/P_alleghaniensis_concatenate_ragtag.scaffolds.fasta"

# Output directory where intermediate run files and final genome assemblies will be saved for the current sample
OUTDIR="$HOME/mendel-nas1/pseudoit_output/"${NAME}

#### Assembly variables used when running bwa, gatk, and bcftools

# max number of processors available to gatk when haplotyping large scaffolds (> 100 megabases)
MAXPROCS=20
# number of processors available to gatk when haplotyping mid-sized scaffolds (10–100 megabases)
MIDPROCS=8
# number of processors available to gatk when haplotyping small scaffolds (<10 megabases)
MINPROCS=1
# Number of threads available to bwa when mapping reads to ref genome
BWA_THREADS=10
# The minimum phred-scaled confidence threshold at which variants should be called (gatk default = 30)
STAND_CALL_CONF=30
# Indel gap size
INDELGAP=5


#### Future assembly variables (not yet implemented)

# Minimum site coverage required by $BCFTOOLSFILTER_SHPATH and $BCFTOOLSFILTER_02_SHPATH
MINSITECOV=5
# Maximum site coverage required by $BCFTOOLSFILTER_SHPATH and $BCFTOOLSFILTER_02_SHPATH
MAXSITECOV=60
# Number of processors to use for bcftools filter (can be low because not rate-limiting)
FILTER_PROCS=1
# Whether or not to keep all intermediate files at the end of an iteration (1=TRUE;0=FALSE) # better to keep all
KEEPALL=1

