#!/bin/bash
#SBATCH --job-name BuildDatabase
#SBATCH --nodes=1
#SBATCH --tasks-per-node=2
#SBATCH --mem=100gb
#SBATCH --time=23:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate repeats
#####

FASTA_IN=${1}
DB_NAME=${2}
DIR_OUT=${3}

cd $DIR_OUT
BuildDatabase -name ${DB_NAME} ${FASTA_IN}
