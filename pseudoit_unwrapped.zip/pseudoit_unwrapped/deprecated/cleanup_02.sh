#!/bin/bash
#SBATCH --job-name cleanup_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=10:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
# conda activate pseudo-it
#####

OUTDIR=$1
KEEPALL=$2
BCFTOOLSCONSENSUS_02_ID=$3
LOGOFLOGS=$4

[ ! -f "$LOGOFLOGS" ] && exit 1

# record that 'bcftools consensus' completed successfully for iteration 2
echo -e ${BCFTOOLSCONSENSUS_02_ID}"\tbcftools_consensus_02\tSUCCESS\t-----" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tcleanup_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

# for now, dont delete any files
exit 0

## if [ ${KEEPALL} -eq 1 ]; then
##   exit 0
## elif [ ${KEEPALL} -eq 0 ]; then
##    # cleanup iteration 2
##    rm ${OUTDIR}"/iter-02/bam/iter-02-dupmets.txt"
##    rm ${OUTDIR}"/iter-02/bam/merged-iter-02.bam.gz"
##    rm ${OUTDIR}"/iter-02/bam/pe-iter-02.bam.gz"
##    rm ${OUTDIR}"/iter-02/bam/se-iter-02.bam.gz"
##    rm ${OUTDIR}"/iter-02/vcf/iter-02-gathervcfs-params.txt"
##    rm -r ${OUTDIR}"/iter-02/vcf/gvcf-scaff"
## fi

