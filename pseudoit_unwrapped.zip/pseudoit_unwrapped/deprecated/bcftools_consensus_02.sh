#!/bin/bash
#SBATCH --job-name bcftools_consensus_02
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=10:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
conda activate pseudo-it
#####

REF_02_SOFTMASKED=$1
SOFTMASKED_02_FINAL_FASTA=$2
SOFTMASKED_02_FINAL_FASTA_CHAIN=$3
FILTER_VCF_02=$4
FIRSTBASEUPPER_02_ID=$5
LOGOFLOGS=$6

[ ! -f "$REF_02_SOFTMASKED" ] && echo $REF_02_SOFTMASKED" not found" && exit 1
[ ! -f "$FILTER_VCF_02" ] && echo $FILTER_VCF_02" not found" && exit 1
[ ! -f "$LOGOFLOGS" ] && echo $LOGOFLOGS" not found" && exit 1

echo -e ${FIRSTBASEUPPER_02_ID}"\tfirst_base_upper_02\tSUCCESS\t-----" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tbcftools_consensus_02\tEXECUTING\t-----" >> ${LOGOFLOGS}

bcftools consensus -f ${REF_02_SOFTMASKED} -o ${SOFTMASKED_02_FINAL_FASTA} -c ${SOFTMASKED_02_FINAL_FASTA_CHAIN} -e "FILTER~'pseudoit' || FILTER~'IndelGap'" ${FILTER_VCF_02}


