#!/bin/bash
#SBATCH --job-name cleanup_01
#SBATCH --nodes=1
#SBATCH --tasks-per-node=10
#SBATCH --mem=10gb
#SBATCH --time=10:00:00
#SBATCH --mail-type=NONE
#SBATCH --output=slurm-%j-%x.out
#SBATCH --error=slurm-%j-%x.out

##### activate conda environment
source ~/.bash_profile
# conda activate pseudo-it
#####


OUTDIR=$1
KEEPALL=$2
BCFTOOLSCONSENSUS_01_ID=$3
LOGOFLOGS=$4

# record that 'bcftools consensus' completed successfully for iteration 1
echo -e ${BCFTOOLSCONSENSUS_01_ID}"\tbcftools_consensus_01\tSUCCESS\t-----" >> ${LOGOFLOGS}
echo -e ${SLURM_JOB_ID}"\tcleanup_01\tEXECUTING\t-----" >> ${LOGOFLOGS}

# for now, dont delete any files
exit 0

## if [ ${KEEPALL} -eq 1 ]; then
##   exit 0
## elif [ ${KEEPALL} -eq 0 ]; then
##    # cleanup iteration 1
##    rm ${OUTDIR}"/iter-01/bam/iter-01-dupmets.txt"
##    rm ${OUTDIR}"/iter-01/bam/merged-iter-01.bam.gz"
##    rm ${OUTDIR}"/iter-01/bam/pe-iter-01.bam.gz"
##    rm ${OUTDIR}"/iter-01/bam/se-iter-01.bam.gz"
##    rm ${OUTDIR}"/iter-01/vcf/iter-01-filter-intermediate.vcf.gz"
##    rm ${OUTDIR}"/iter-01/vcf/iter-01-filter-intermediate.vcf.gz.tbi"
##    rm ${OUTDIR}"/iter-01/vcf/iter-01-gathervcfs-params.txt"
##    rm -R ${OUTDIR}"/iter-01/vcf/vcf-scaff"
## fi

